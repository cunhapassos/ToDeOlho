//
//  TermosDeUsoViewController.swift
//  ToDeOlho
//
//  Created by Paulo Passos on 16/02/19.
//  Copyright © 2019 paulopassos. All rights reserved.
//

import UIKit

class TermosDeUsoViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func fechar(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
}
